<?php include "header.php" ?>
	<div class="card" style="width: 18rem;">
	  <div class="card-body">
		<h3 class="card-title">Regions</h3>
		<p class="card-text">25</p>
	  </div>
	</div>
	
	<div class="card" style="width: 18rem;">
	  <div class="card-body">
		<h3 class="card-title">Employees</h3>
		<p class="card-text">100</p>
	  </div>
	</div>
	
	<div class="card" style="width: 18rem;">
	  <div class="card-body">
		<h3 class="card-title">Customers</h3>
		<p class="card-text">1000</p>
	  </div>
	</div>
<?php include "footer.php" ?>
		